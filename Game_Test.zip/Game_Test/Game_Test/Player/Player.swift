//
//  Player.swift
//  Game_Test
//
//  Created by SHTeosis on 9/21/24.
//

import Foundation

class Player: ObservableObject
{
	@Published var pos: Pos = Pos()
	let iffType = IFFLayer.PLAYER
	var controller: Controller = Controller()
	var imageName: String = "Fight_Aerocraft_Player"
	
	init()
	{
		pos.x += 10
		pos.y += 300
	}
	
	func Update()
	{
		controller.Update()
		pos.x += controller.motionPos.x
		pos.y += controller.motionPos.y
	}
}


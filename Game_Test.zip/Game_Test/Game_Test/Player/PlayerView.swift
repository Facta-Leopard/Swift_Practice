//
//  PlayerView.swift
//  Game_Test
//
//  Created by SHTeosis on 9/21/24.
//

import SwiftUI

struct PlayerView: View
{
    var body: some View
	{
		let player: Player = Player()
		Image("Fight_Aerocraft_Player")
			.resizable()
			.frame(width: 150, height: 150)
			.position(x : CGFloat(player.pos.x), y : CGFloat(player.pos.y))
    }
}

#Preview {
    PlayerView()
}

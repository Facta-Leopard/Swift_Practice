//
//  Engine.swift
//  Game_Test
//
//  Created by SHTeosis on 9/21/24.
//

import Foundation
import Combine

class GameEngine : ObservableObject
{
    @Published var isRunning : Bool = false
	@Published var player = Player()
	
	var timer: AnyCancellable?
	
    init()
    {
    }
    
	// 게임 시작
    func startGame()
    {
        isRunning = true
        
		timer = Timer.publish(every: 1.0/60.0, on: .main, in: .common)
			.autoconnect()
			.sink
			{_ in
				self.update()
			}
        
    }
    
    // 게임 상태 업데이트
    func update()
    {
		player.Update()
    }

    // 게임 중지
    func stopGame()
    {
		isRunning = false
		timer?.cancel()
    }
}

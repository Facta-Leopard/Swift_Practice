//
//  Pos.swift
//  Game_Test
//
//  Created by SHTeosis on 9/21/24.
//

import Foundation
import UIKit

// 핸드폰 기기에 따른 전체화면 크기 확인
let screenBounds = UIScreen.main.bounds

// 전체화면 가로 길이
let screenWidth = screenBounds.width

// 전체화면 세로 길이
let screenHeight = screenBounds.height

// 좌표
struct Pos
{
	var x: Int
	var y: Int

	// 화면 중앙 좌표 초기화
	init()
	{
		x = Int(screenWidth / 2)
		y = Int(screenHeight / 2)
	}
	init(_x: Any, _y: Any)
	{
		x = _x as? Int ?? 0
		y = _y as? Int ?? 0
	}
	
	// 좌표계 업데이트
	// 구조체 값을 바꾸려면 mutating을 붙혀야 한다는 걸 처음 알았네.. 이거 떄문에 또 몇시간 삽질...
	mutating func Update(_Pos : Pos)
	{

		x += _Pos.x
		y += _Pos.y
	}
	
}

// 크기
struct Scale
{
	var width: Int
	var height: Int
	
	init()
	{
		width = 75
		height = 75
	}
	init(_width: Int, _height: Int)
	{
		width = _width
		height = _height
	}
	
}

// 속도
struct Velocity
{
	var x: Double
	var y: Double
	
	init()
	{
		x = 0
		y = 0
	}
	init(_x : Double, _y: Double)
	{
		x = _x
		y = _y
	}
	
}

// 가속도계 구조체(자이로스코프 및 가속계 사용용도)
struct Accel
{
	var x: Double
	var y: Double
	var z: Double
	
	init()
	{
		x = 0
		y = 0
		z = 0
	}
	init(x: Double, y: Double, z: Double)
	{
		self.x = x
		self.y = y
		self.z = z
	}
}

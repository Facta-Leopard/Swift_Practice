//
//  Controller.swift
//  Game_Test
//
//  Created by SHTeosis on 9/21/24.
//

import Foundation
// 자이로스코프 및 가속도계 프레임워크
import CoreMotion


class Controller: ObservableObject {
	// 자이로스코프 및 가속도계 프레임워크 안의 데이터 클래스
	let motionManager = CMMotionManager()
	open var motionPos = Pos()
	private var motionVelocity = Velocity()
	private var accel = Accel(x: 0, y: 0, z: 0) // 초기화
	private var currentAccel: CMAcceleration?
	private var time = Time()
	
	init() {
		StartAccelerometerUpdates()
	}
	
	// 가속도계 업데이트 시작
	func StartAccelerometerUpdates() {
		let deltaTime = time.deltaTime
		
		// 가속도계를 델타타임으로 업데이트
		motionManager.accelerometerUpdateInterval = deltaTime
		
		// 가속도계 데이터를 받아옴
		motionManager.startAccelerometerUpdates(to: OperationQueue.current!) { data, error in
			if let acceleration = data?.acceleration {
				// 가속도 값을 accel에 업데이트
				self.accel.x = acceleration.x
				self.accel.y = acceleration.y
				self.accel.z = acceleration.z
				
				// 현재 가속도 업데이트
				self.currentAccel = acceleration
			}
		}
	}
	
	func Update() {
		let deltaTime = time.deltaTime
		
		guard let acceleration = currentAccel else { return }
		
		let accelerationX = acceleration.x
		let accelerationY = acceleration.y
		
		// 속도 및 위치 업데이트
		motionVelocity.x += accelerationX * deltaTime
		motionVelocity.y += accelerationY * deltaTime
		
		// 좌표 업데이트
		motionPos.x += Int(motionVelocity.x * deltaTime)
		motionPos.y += Int(motionVelocity.y * deltaTime)
	}
}

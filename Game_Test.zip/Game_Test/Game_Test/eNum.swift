//
//  IFF.swift
//  Game_Test
//
//  Created by SHTeosis on 9/21/24.
//

import Foundation

enum IFFLayer
{
	// 스타일 분류
	case PLAYER
	case FRIEND
	case FOE
	
	// 투사체 분류
	case PLAYERMISSLE
	case FRIENDMISSLE
	case FOEMISSLE
}

//
//  View.swift
//  Game_Test
//
//  Created by SHTeosis on 9/21/24.
//

import SwiftUI
@main
struct Game_TestApp: App
{
	@StateObject private var gameEngine: GameEngine = .init()
	
	var body: some Scene
    {
        WindowGroup
        {
            MainView(gameEngine: gameEngine)
        }
    }
}
struct MainView: View
{
	@ObservedObject var gameEngine: GameEngine
	
    var body: some View
	{
		NavigationStack
		{
			VStack
			{
				
				Text("슈팅게임 테스트용")
					.font(.title2)
					.fontWeight(.bold)
					.foregroundColor(.white)
					.opacity(0.8)
					.padding(.top, 40)
				Spacer()
				
				// 게임시작 버튼
				Button(action:
								{
									gameEngine.isRunning.toggle()
									if gameEngine.isRunning
									{
										gameEngine.startGame()
									}
									else
									{
										gameEngine.stopGame()
									}
								}
						)
				{
					Text("Game_Start")
						.font(.title)
						.fontWeight(.bold)
						.padding()
						.frame(width: 200, height: 60)
						.background(Color.mint)
						.foregroundColor(.white)
						.cornerRadius(15)
						.shadow(radius: 5)
						.opacity(0.7)
				}
				.navigationDestination(isPresented: $gameEngine.isRunning)
				{
					GameView(gameEngine: gameEngine)
						.navigationBarBackButtonHidden(true)
				}
			}
			.frame(maxWidth: .infinity, maxHeight: .infinity)
			// 메인화면 배경이미지
			.background(
				Image("MainView_BGIMG")
					.resizable()
					.aspectRatio(contentMode: .fill)
					.edgesIgnoringSafeArea(.vertical)
			)
			
		}
	}
}





#Preview {
	MainView(gameEngine: GameEngine())
		
}

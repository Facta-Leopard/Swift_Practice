//
//  GameView.swift
//  Game_Test
//
//  Created by SHTeosis on 9/21/24.
//

import SwiftUI

struct GameView: View {
	@ObservedObject var gameEngine: GameEngine
	@State private var showExitMenu = false
	
	var body: some View {
		ZStack
		{
			// 게임 배경
			Image("Game_BGIMG")
				.resizable()
				.aspectRatio(contentMode: .fill)
				.edgesIgnoringSafeArea(.all)
			
			PlayerView()

			
			
			if showExitMenu {
				Color.black.opacity(0.5)
					.edgesIgnoringSafeArea(.all)
					.onTapGesture {
						withAnimation {
							showExitMenu = false
						}
					}
				
				// 종료창 모달박스
				VStack {
					Text("Exit Game?")
						.foregroundColor(.white)
						.padding()
					
					// 모달박스 내 버튼
					HStack {
						
						Button("Exit") {
							gameEngine.isRunning = false
						}
						.padding()
						.background(Color.red)
						.foregroundColor(.white)
						.cornerRadius(10)

						Button("Cancel") {
							withAnimation {
								showExitMenu = false
							}
						}
						.padding()
						.background(Color.gray)
						.foregroundColor(.white)
						.cornerRadius(10)

					}
				}
			}
		}
		.overlay(
			Button(action: {
				withAnimation {
					showExitMenu.toggle()
				}
			}) {
				Image(systemName: "xmark")
					.imageScale(.large)
					.padding()
					.foregroundColor(.white)
			}
				.padding(),
			alignment: .topLeading
		)
	}
}
